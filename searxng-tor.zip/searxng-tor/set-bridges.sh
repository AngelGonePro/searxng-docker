#!/usr/bin/env bash
# ==============================================================================
# set-bridges.sh - give Tor its obfs4 bridges WITHOUT hand-editing any file.
#
# Needed only if your network blocks Tor relays (symptom: the tor container
# sits at "Bootstrapped 30%" / "Stuck at 30%" and the site shows 502).
#
#   ./set-bridges.sh                 paste bridge lines when asked (blank line = done)
#   ./set-bridges.sh "obfs4 ..." "obfs4 ..."     or pass them as arguments
#   ./set-bridges.sh --clear         remove all bridges (connect directly again)
#
# Get bridge lines (each starts with "obfs4") from https://bridges.torproject.org
# (Obfs4) or by emailing bridges@torproject.org from a Gmail address with the
# body:  get transport obfs4
#
# It writes them into .env (TOR_BRIDGE_1..3), recreates the tor container,
# waits until Tor reports "Bootstrapped 100%", then restarts searxng.
# deploy-update.sh never overwrites these values.
# ==============================================================================
set -euo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f .env ] || { echo "ERROR: no .env here - run from your searxng-tor folder." >&2; exit 1; }

bridges=()
clean_line() {
  local l="$1"
  l="${l%$'\r'}"
  l="${l#"${l%%[![:space:]]*}"}"      # trim leading space
  l="${l%"${l##*[![:space:]]}"}"      # trim trailing space
  case "$l" in Bridge\ *|bridge\ *) l="${l#* }" ;; esac
  printf '%s' "$l"
}
add_bridge() {
  local l; l="$(clean_line "$1")"
  [ -z "$l" ] && return 0
  case "$l" in
    obfs4\ *) ;;
    *) echo "Skipping (not an obfs4 line): $l" >&2; return 0 ;;
  esac
  bridges+=("$l")
}

if [ "${1:-}" = "--clear" ]; then
  :
elif [ "$#" -gt 0 ]; then
  for a in "$@"; do add_bridge "$a"; done
else
  echo "Paste your obfs4 bridge lines (one per line). Press Enter on an empty line when done:"
  while IFS= read -r line; do
    [ -z "$(clean_line "$line")" ] && break
    add_bridge "$line"
  done
fi

if [ "${1:-}" != "--clear" ] && [ "${#bridges[@]}" -eq 0 ]; then
  echo "ERROR: no valid obfs4 bridge lines given - nothing changed." >&2
  exit 1
fi
if [ "${#bridges[@]}" -gt 3 ]; then
  echo "Note: only the first 3 bridges are used (TOR_BRIDGE_1..3)." >&2
fi

# Rewrite TOR_BRIDGE_1..3 in .env (values contain / + = so no sed).
cp -p .env ".env.bak.$(date +%Y%m%d-%H%M%S)"
tmp="$(mktemp)"
declare -A seen=()
while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in
    TOR_BRIDGE_[123]=*)
      n="${line:11:1}"
      seen[$n]=1
      printf 'TOR_BRIDGE_%s=%s\n' "$n" "${bridges[$((n-1))]:-}" >> "$tmp"
      ;;
    *) printf '%s\n' "$line" >> "$tmp" ;;
  esac
done < .env
for n in 1 2 3; do
  [ -n "${seen[$n]:-}" ] || printf 'TOR_BRIDGE_%s=%s\n' "$n" "${bridges[$((n-1))]:-}" >> "$tmp"
done
cat "$tmp" > .env
rm -f "$tmp"
echo "==> Saved ${#bridges[@]} bridge(s) to .env"

echo "==> Restarting Tor"
docker compose up -d --force-recreate tor
echo "==> Waiting for Tor to connect (up to 3 minutes)..."
ok=0
for i in $(seq 1 36); do
  if docker compose logs tor 2>&1 | grep -q 'Bootstrapped 100%'; then ok=1; break; fi
  sleep 5
done
if [ "$ok" -eq 1 ]; then
  echo "==> Tor is connected. Restarting searxng"
  docker compose restart searxng
  echo "==> Done. Give searxng ~30 seconds to start, then reload the site."
else
  echo "==> Tor did NOT reach 100% in 3 minutes. Last log lines:" >&2
  docker compose logs --tail=8 tor >&2
  echo "Try different bridge lines (get fresh ones) and run this script again." >&2
  exit 2
fi
