#!/bin/sh
# ==============================================================================
# Idle-aware auto-updater for the searxng-tor stack.
#
# Every CHECK_INTERVAL seconds, counts real search requests (GET /search?q=)
# in the searxng container's log since the last check. Static asset requests
# (css/js/favicon/opensearch.xml) are deliberately ignored so a browser tab
# left open on the page doesn't count as "someone searching."
#
# Once IDLE_MINUTES worth of consecutive empty checks have passed, it runs
# `docker compose pull` + `docker compose up -d` to update and recreate any
# containers whose image changed, then resets and goes back to watching.
# ==============================================================================
set -eu

CHECK_INTERVAL="${CHECK_INTERVAL:-300}"        # seconds between activity checks
IDLE_MINUTES="${IDLE_MINUTES:-15}"             # required idle minutes before updating
SEARXNG_CONTAINER="${SEARXNG_CONTAINER:-searxng}"
PROJECT_DIR="${PROJECT_DIR:?PROJECT_DIR must be set}"

checks_needed=$(( (IDLE_MINUTES * 60 + CHECK_INTERVAL - 1) / CHECK_INTERVAL ))
idle_checks=0

log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*"; }

log "updater starting: checking every ${CHECK_INTERVAL}s, updating after ${checks_needed} consecutive idle checks (~${IDLE_MINUTES}m of no searches)"

while true; do
    sleep "$CHECK_INTERVAL"

    activity=$(docker logs --since "${CHECK_INTERVAL}s" "$SEARXNG_CONTAINER" 2>&1 | grep -c '"GET /search?q=' || true)

    if [ "$activity" -gt 0 ]; then
        idle_checks=0
        log "activity detected (${activity} search request(s) this interval) — idle timer reset"
        continue
    fi

    idle_checks=$((idle_checks + 1))
    log "no searches this interval — idle streak: ${idle_checks}/${checks_needed}"

    if [ "$idle_checks" -ge "$checks_needed" ]; then
        log "idle threshold reached — pulling images"
        cd "$PROJECT_DIR"
        if docker compose --env-file .env pull; then
            log "recreating any containers whose image changed"
            docker compose --env-file .env up -d --remove-orphans
            docker image prune -f >/dev/null 2>&1 || true
            log "update pass complete"
        else
            log "pull failed — will retry after the next idle window"
        fi
        idle_checks=0
    fi
done
