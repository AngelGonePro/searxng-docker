#!/bin/bash
# ==============================================================================
# Manual update command for the searxng-tor stack. Run this yourself
# whenever you want to check for and apply a newer SearXNG version — this
# stack does NOT auto-update anymore.
#
# What it does, in order:
#   1. Reads the currently pinned SEARXNG_VERSION from .env.
#   2. Pulls searxng/searxng:latest and reads its actual version out of
#      the image itself (no guessing).
#   3. If there's a newer version, builds a TEST image with it — the
#      live stack is not touched yet.
#   4. Runs that test image as a disposable, isolated container (same
#      network, same .env) and checks it both stays running AND actually
#      answers an HTTP request — this is what catches the kind of
#      breaking change that hit this stack more than once already
#      (an entrypoint path moving, a settings.yml schema change, an
#      internal template rename).
#   5. Only if that check passes does it update .env and rebuild the
#      real stack. If it fails, nothing about the running instance
#      changes — you're told what broke and the live stack keeps running
#      exactly as it was.
#
# Usage:  ./update.sh
# ==============================================================================
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -f docker-compose.yml ] || [ ! -f .env ]; then
    echo "Run this from the searxng-tor project root (docker-compose.yml / .env not found here)." >&2
    exit 1
fi

# shellcheck disable=SC1091
source .env

HEALTH_WAIT="${UPDATE_HEALTH_WAIT:-20}"
NETWORK_NAME="searxng-tor_searxng-net"
TEST_IMAGE="searxng-tor-searxng:update-test"
TEST_CONTAINER="searxng-update-test"

if [ -z "${SEARXNG_VERSION:-}" ]; then
    echo "SEARXNG_VERSION isn't set in .env — can't tell what's currently pinned." >&2
    exit 1
fi

echo "Current pinned SearXNG version: ${SEARXNG_VERSION}"
echo "Checking for a newer version..."

docker pull -q searxng/searxng:latest >/dev/null

NEW_VERSION=$(docker run --rm --entrypoint cat searxng/searxng:latest \
    /usr/local/searxng/searx/version_frozen.py \
    | grep '^DOCKER_TAG' | sed -E 's/DOCKER_TAG = "(.*)"/\1/')

if [ -z "$NEW_VERSION" ]; then
    echo "Couldn't determine the latest version from the pulled image — aborting, nothing changed." >&2
    exit 1
fi

echo "Latest available: ${NEW_VERSION}"

if [ "$NEW_VERSION" = "$SEARXNG_VERSION" ]; then
    echo "Already up to date."
    exit 0
fi

echo ""
echo "=== Building a test image with ${NEW_VERSION} (live stack untouched so far) ==="
docker build --build-arg SEARXNG_VERSION="$NEW_VERSION" -t "$TEST_IMAGE" ./searxng

echo ""
echo "=== Starting a disposable test container to verify it actually works ==="
docker rm -f "$TEST_CONTAINER" >/dev/null 2>&1 || true

TEST_PORT="${SEARXNG_PORT:-8080}"

docker run -d \
    --name "$TEST_CONTAINER" \
    --network "$NETWORK_NAME" \
    --env-file .env \
    -e SEARXNG_PORT="$TEST_PORT" \
    -e SEARXNG_BIND_ADDRESS=0.0.0.0 \
    -e SEARXNG_LIMITER=false \
    -p "127.0.0.1::${TEST_PORT}" \
    "$TEST_IMAGE" >/dev/null

HOST_PORT=$(docker port "$TEST_CONTAINER" "${TEST_PORT}/tcp" | head -1 | cut -d: -f2)

echo "Test container up on 127.0.0.1:${HOST_PORT} — waiting ${HEALTH_WAIT}s before checking it"
sleep "$HEALTH_WAIT"

STATUS=$(docker inspect --format '{{.State.Status}}' "$TEST_CONTAINER" 2>/dev/null || echo "missing")
HTTP_CODE="000"
if [ "$STATUS" = "running" ]; then
    HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "http://127.0.0.1:${HOST_PORT}/" || echo "000")
fi

echo "Container status: ${STATUS}, HTTP response: ${HTTP_CODE}"

docker logs "$TEST_CONTAINER" --tail 30 > /tmp/searxng-update-test.log 2>&1 || true
docker rm -f "$TEST_CONTAINER" >/dev/null 2>&1 || true

if [ "$STATUS" = "running" ] && [ "$HTTP_CODE" = "200" ]; then
    echo ""
    echo "=== ${NEW_VERSION} checks out — applying it ==="
    sed -i.bak "s/^SEARXNG_VERSION=.*/SEARXNG_VERSION=${NEW_VERSION}/" .env
    rm -f .env.bak
    docker compose up -d --build
    echo ""
    echo "Updated to ${NEW_VERSION}. Run 'docker compose ps' to confirm everything's up, and take a look to make sure nothing looks off."
else
    echo ""
    echo "=== ${NEW_VERSION} FAILED its check — nothing changed, still running ${SEARXNG_VERSION} ==="
    echo "Last 30 log lines from the failed test container:"
    cat /tmp/searxng-update-test.log
    exit 1
fi
