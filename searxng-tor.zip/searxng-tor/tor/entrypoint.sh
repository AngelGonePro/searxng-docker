#!/bin/sh
# ==============================================================================
# Generates /etc/tor/torrc from scratch at every container start and execs
# tor. Written this way (rather than using dperson/torproxy's own flags)
# because dperson/torproxy has no bridge/pluggable-transport support at
# all — confirmed against its full documented option list (-b, -e, -l,
# -n, -p, -s). Full control here means bridges, the control port, and its
# password are all explicit rather than depending on another script's
# behavior we can't see.
#
# Bridges are OPTIONAL and auto-detected: if none of TOR_BRIDGE_1/2/3 are
# set, this generates a normal torrc that connects directly to the public
# Tor network like before. Set one or more to switch to bridge mode —
# useful when the network this container runs on blocks connections to
# publicly-known Tor relay IPs specifically (a real, fairly common
# pattern for both ISPs and some hosting providers) while leaving normal
# HTTPS untouched.
# ==============================================================================
set -eu

TOR_CONTROL_PASSWORD="${TOR_CONTROL_PASSWORD:?TOR_CONTROL_PASSWORD must be set}"
TORRC=/etc/tor/torrc

# /var/lib/tor is created by the tor package already owned by debian-tor
# with mode 700, so no chmod/chown is needed (and the container does not
# have the capabilities for it: cap_drop ALL).
mkdir -p /var/lib/tor

HASHED_PW="$(tor --hash-password "$TOR_CONTROL_PASSWORD" 2>/dev/null | tail -1)"

{
    echo "SocksPort 0.0.0.0:9050"
    echo "ControlPort 0.0.0.0:9051"
    echo "HashedControlPassword $HASHED_PW"
    echo "DataDirectory /var/lib/tor"
    echo "User debian-tor"
    echo "Log notice stdout"
} > "$TORRC"

bridge_count=0
for var in TOR_BRIDGE_1 TOR_BRIDGE_2 TOR_BRIDGE_3; do
    value=$(eval "echo \"\${${var}:-}\"")
    if [ -n "$value" ]; then
        if [ "$bridge_count" -eq 0 ]; then
            echo "UseBridges 1" >> "$TORRC"
            echo "ClientTransportPlugin obfs4 exec /usr/bin/obfs4proxy" >> "$TORRC"
        fi
        echo "Bridge $value" >> "$TORRC"
        bridge_count=$((bridge_count + 1))
    fi
done

if [ "$bridge_count" -gt 0 ]; then
    echo "[entrypoint] configured with $bridge_count bridge(s)" >&2
else
    echo "[entrypoint] no TOR_BRIDGE_* set — connecting directly to the public Tor network" >&2
fi

exec tor -f "$TORRC"
