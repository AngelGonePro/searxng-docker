#!/usr/bin/env bash
# ==============================================================================
# deploy-update.sh - pull the latest searxng-tor release zip from GitHub and
# apply it over this install WITHOUT touching your real .env values.
#
#   ./deploy-update.sh
#
# What it does:
#   1. Downloads searxng-tor.zip and unpacks it into a temp folder.
#   2. Copies every file over this install EXCEPT .env.
#   3. Appends any NEW settings that exist in the release's .env but not in
#      yours (your existing values are never changed). A backup of your .env
#      is saved first as .env.bak.<timestamp>.
#   4. Rebuilds and restarts the stack: docker compose up -d --build
#
# Not touched: your .env values, Docker volumes (caddy_data), the pinned
# SEARXNG_VERSION (that is only changed by ./update.sh after a passing test).
#
# Override the download location if you host the zip elsewhere:
#   SEARXNG_TOR_ZIP_URL=https://example.com/searxng-tor.zip ./deploy-update.sh
# ==============================================================================
set -euo pipefail

ZIP_URL="${SEARXNG_TOR_ZIP_URL:-https://raw.githubusercontent.com/AngelGonePro/searxng-docker/refs/heads/main/searxng-tor.zip}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

for tool in curl unzip docker; do
  command -v "$tool" >/dev/null 2>&1 || { echo "ERROR: '$tool' is required but not installed." >&2; exit 1; }
done
[ -f .env ] || { echo "ERROR: no .env in $HERE - run this from your existing install folder." >&2; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "==> Downloading $ZIP_URL"
curl -fL --retry 3 -o "$TMP/release.zip" "$ZIP_URL"
unzip -q "$TMP/release.zip" -d "$TMP/extract"

SRC="$TMP/extract/searxng-tor"
[ -f "$SRC/docker-compose.yml" ] || { echo "ERROR: zip doesn't contain searxng-tor/docker-compose.yml" >&2; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
cp -p .env ".env.bak.$STAMP"
echo "==> Backed up .env to .env.bak.$STAMP"

# Pull out the release's .env so the copy below can't overwrite yours.
mv "$SRC/.env" "$TMP/new.env"

echo "==> Copying updated files"
cp -a "$SRC/." "$HERE/"

# Append settings that are new in the release (compared by KEY, not by value).
added=0
while IFS= read -r line; do
  case "$line" in
    [A-Za-z_]*=*) key="${line%%=*}" ;;
    *) continue ;;
  esac
  if ! grep -q "^${key}=" .env; then
    if [ "$added" -eq 0 ]; then
      printf '\n# ---- added by deploy-update.sh %s ----\n' "$STAMP" >> .env
    fi
    printf '%s\n' "$line" >> .env
    echo "    + new setting: $key"
    added=$((added + 1))
  fi
done < "$TMP/new.env"
[ "$added" -eq 0 ] && echo "==> No new .env settings"

chmod +x update.sh deploy-update.sh set-bridges.sh rotator/rotate.sh tor/entrypoint.sh searxng/entrypoint.sh 2>/dev/null || true

echo "==> Rebuilding and restarting"
docker compose up -d --build
echo "==> Done."
