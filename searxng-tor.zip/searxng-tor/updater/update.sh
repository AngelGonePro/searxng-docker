#!/bin/sh
# ==============================================================================
# Idle-aware auto-updater + Tor circuit rotator for the searxng-tor stack.
#
# Two independent jobs on the same loop, since both piggyback on the
# docker.sock access this container already needs:
#
# 1. UPDATES — every CHECK_INTERVAL seconds, counts real search requests
#    (GET /search?q=) in the searxng container's log since the last check.
#    Static asset requests (css/js/favicon/opensearch.xml) are deliberately
#    ignored so a browser tab left open doesn't count as "someone
#    searching." Once IDLE_MINUTES worth of consecutive empty checks have
#    passed, it runs `docker compose pull` + `up -d` and resets.
#
# 2. TOR ROTATION — independent of the above, every ROTATE_MINUTES it asks
#    the tor container for a fresh circuit (new exit IP) via its built-in
#    `torproxy.sh -n`, run through `docker exec` rather than talking to the
#    control port over the network — the image already knows its own
#    control-port password internally, so this needs nothing extra beyond
#    PASSWORD being set on the tor service. This won't rescue engines that
#    actively CAPTCHA-challenge Tor circuits (Startpage does this
#    regardless of IP), but it does clear plain IP-based rate limits
#    (Brave-style "too many requests") once the old exit node is dropped.
# ==============================================================================
set -eu

CHECK_INTERVAL="${CHECK_INTERVAL:-300}"        # seconds between checks (both jobs)
IDLE_MINUTES="${IDLE_MINUTES:-15}"             # required idle minutes before updating
ROTATE_MINUTES="${ROTATE_MINUTES:-10}"         # how often to rotate the Tor circuit
SEARXNG_CONTAINER="${SEARXNG_CONTAINER:-searxng}"
TOR_CONTAINER="${TOR_CONTAINER:-searxng-tor}"
PROJECT_DIR="${PROJECT_DIR:?PROJECT_DIR must be set}"

idle_checks_needed=$(( (IDLE_MINUTES * 60 + CHECK_INTERVAL - 1) / CHECK_INTERVAL ))
rotate_checks_needed=$(( (ROTATE_MINUTES * 60 + CHECK_INTERVAL - 1) / CHECK_INTERVAL ))
idle_checks=0
rotate_checks=0

log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*"; }

log "updater starting: checking every ${CHECK_INTERVAL}s — update after ${idle_checks_needed} idle checks (~${IDLE_MINUTES}m), rotate Tor circuit every ${rotate_checks_needed} checks (~${ROTATE_MINUTES}m)"

while true; do
    sleep "$CHECK_INTERVAL"

    # --- job 1: idle-triggered update -----------------------------------
    activity=$(docker logs --since "${CHECK_INTERVAL}s" "$SEARXNG_CONTAINER" 2>&1 | grep -c '"GET /search?q=' || true)

    if [ "$activity" -gt 0 ]; then
        idle_checks=0
        log "activity detected (${activity} search request(s) this interval) — idle timer reset"
    else
        idle_checks=$((idle_checks + 1))
        log "no searches this interval — idle streak: ${idle_checks}/${idle_checks_needed}"

        if [ "$idle_checks" -ge "$idle_checks_needed" ]; then
            log "idle threshold reached — pulling images"
            cd "$PROJECT_DIR"
            if docker compose --env-file .env pull; then
                log "recreating any containers whose image changed"
                docker compose --env-file .env up -d --remove-orphans
                docker image prune -f >/dev/null 2>&1 || true
                log "update pass complete"
            else
                log "pull failed — will retry after the next idle window"
            fi
            idle_checks=0
        fi
    fi

    # --- job 2: periodic Tor circuit rotation ----------------------------
    rotate_checks=$((rotate_checks + 1))
    if [ "$rotate_checks" -ge "$rotate_checks_needed" ]; then
        if docker exec "$TOR_CONTAINER" torproxy.sh -n >/dev/null 2>&1; then
            log "rotated Tor circuit (new exit node requested)"
        else
            log "Tor circuit rotation failed — is PASSWORD set on the tor service?"
        fi
        rotate_checks=0
    fi
done
