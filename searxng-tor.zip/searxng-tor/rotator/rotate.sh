#!/bin/sh
# ==============================================================================
# Tor circuit rotator. Every ROTATE_MINUTES, sends AUTHENTICATE + SIGNAL
# NEWNYM directly to Tor's control port (tor:9051) over the compose
# network, asking for a fresh exit circuit — helps engines that rate-
# limit heavily-shared Tor exit IPs (Brave-style "too many requests").
# Won't help engines that categorically block Tor outright regardless of
# exit node (Startpage's CAPTCHA wall does this) — see TOR_BYPASS_* in
# .env for those instead.
#
# Talks to the control port directly over the network rather than via
# `docker exec`, so this container needs no docker.sock access at all —
# unlike the old updater sidecar, this one can't touch anything outside
# itself.
# ==============================================================================
set -eu

ROTATE_MINUTES="${ROTATE_MINUTES:-10}"
TOR_HOST="${TOR_HOST:-tor}"
TOR_CONTROL_PORT="${TOR_CONTROL_PORT:-9051}"
TOR_CONTROL_PASSWORD="${TOR_CONTROL_PASSWORD:?TOR_CONTROL_PASSWORD must be set}"

log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*"; }

log "rotator starting: requesting a new Tor circuit every ${ROTATE_MINUTES}m"

while true; do
    sleep "$((ROTATE_MINUTES * 60))"

    response=$(printf 'AUTHENTICATE "%s"\r\nSIGNAL NEWNYM\r\nQUIT\r\n' "$TOR_CONTROL_PASSWORD" \
        | nc -w 10 "$TOR_HOST" "$TOR_CONTROL_PORT" 2>&1 || true)

    if echo "$response" | grep -q "250 OK"; then
        log "rotated Tor circuit (new exit node requested)"
    else
        log "Tor circuit rotation failed — response: $(echo "$response" | tr '\n' ' ')"
    fi
done
