#!/usr/bin/env python3
"""
Runs once at DOCKER BUILD TIME (not container start). Finds this exact
image's own base.html template and static css directory by searching for
them rather than assuming a fixed path — the same lesson learned the hard
way elsewhere in this project (entrypoint.sh's path broke once already
when a searxng/searxng release moved it). If the search comes up empty,
this fails the build loudly and immediately, which is the safe failure
mode: `docker build` just errors out and the live stack is never touched,
rather than shipping a broken image that crashes at runtime.
"""
import glob
import os
import shutil
import sys

SEARXNG_ROOT = "/usr/local/searxng/searx"
CUSTOM_CSS_SRC = "/opt/render/custom-cosmoscraft.css"
CSS_FILENAME = "custom-cosmoscraft.css"


def find_preferring_simple(pattern: str, label: str) -> str:
    matches = glob.glob(pattern)
    if not matches:
        print(f"ERROR: no {label} found matching {pattern}", file=sys.stderr)
        sys.exit(1)
    for m in matches:
        if "/simple/" in m:
            return m
    return matches[0]


def main() -> int:
    base_html = find_preferring_simple(
        f"{SEARXNG_ROOT}/templates/*/base.html", "base.html template"
    )
    css_dir = find_preferring_simple(
        f"{SEARXNG_ROOT}/static/themes/*/css", "theme css directory"
    )

    with open(base_html, "r", encoding="utf-8") as f:
        content = f.read()

    link_tag = f'<link rel="stylesheet" href="/static/themes/simple/css/{CSS_FILENAME}">'

    if CSS_FILENAME in content:
        print(f"[style] {base_html} already references {CSS_FILENAME}, skipping", file=sys.stderr)
    else:
        if "</head>" not in content:
            print(f"ERROR: {base_html} has no </head> to anchor the stylesheet link on", file=sys.stderr)
            return 1
        content = content.replace("</head>", f"{link_tag}\n</head>", 1)
        with open(base_html, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[style] patched {base_html}", file=sys.stderr)

    shutil.copy(CUSTOM_CSS_SRC, os.path.join(css_dir, CSS_FILENAME))
    print(f"[style] installed custom CSS into {css_dir}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
