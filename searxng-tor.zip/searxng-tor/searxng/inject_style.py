#!/usr/bin/env python3
"""
Runs once at DOCKER BUILD TIME (not container start). Finds this exact
image's own base.html template and where its theme's static files
actually live by searching, rather than assuming a fixed path — the
static layout has already turned out to vary between versions (some
ship a css/ subfolder, this one keeps compiled CSS flat directly under
static/themes/simple/). If nothing matching is found, this fails the
build loudly and immediately — `docker build` errors out and the live
stack is never touched, rather than shipping a broken image.
"""
import glob
import os
import shutil
import sys

SEARXNG_ROOT = "/usr/local/searxng/searx"
CUSTOM_CSS_SRC = "/opt/render/custom-cosmoscraft.css"
CSS_FILENAME = "custom-cosmoscraft.css"


def find_preferring_simple(pattern: str, label: str) -> str:
    matches = glob.glob(pattern)
    if not matches:
        print(f"ERROR: no {label} found matching {pattern}", file=sys.stderr)
        sys.exit(1)
    for m in matches:
        if "/simple/" in m:
            return m
    return matches[0]


def find_css_dir() -> str:
    # Preferred: a dedicated css/ subfolder under the theme directory.
    candidates = [d for d in glob.glob(f"{SEARXNG_ROOT}/static/themes/*/css") if os.path.isdir(d)]
    if candidates:
        for c in candidates:
            if "/simple/" in c:
                return c
        return candidates[0]

    # Fallback: compiled assets sit flat directly in the theme directory
    # (confirmed layout for at least one real version of this image).
    theme_dirs = [d for d in glob.glob(f"{SEARXNG_ROOT}/static/themes/*") if os.path.isdir(d)]
    if not theme_dirs:
        print(f"ERROR: no theme directory found under {SEARXNG_ROOT}/static/themes", file=sys.stderr)
        sys.exit(1)
    for d in theme_dirs:
        if "/simple/" in d:
            return d
    return theme_dirs[0]


def main() -> int:
    base_html = find_preferring_simple(
        f"{SEARXNG_ROOT}/templates/*/base.html", "base.html template"
    )
    css_dir = find_css_dir()

    # Build the URL path from wherever css_dir actually turned out to be,
    # rather than hardcoding /css/ into it — this is what broke last time.
    static_root = os.path.join(SEARXNG_ROOT, "static")
    rel_path = os.path.relpath(css_dir, static_root)
    css_url = f"/static/{rel_path}/{CSS_FILENAME}"

    with open(base_html, "r", encoding="utf-8") as f:
        content = f.read()

    link_tag = f'<link rel="stylesheet" href="{css_url}">'

    if CSS_FILENAME in content:
        print(f"[style] {base_html} already references {CSS_FILENAME}, skipping", file=sys.stderr)
    else:
        if "</head>" not in content:
            print(f"ERROR: {base_html} has no </head> to anchor the stylesheet link on", file=sys.stderr)
            return 1
        content = content.replace("</head>", f"{link_tag}\n</head>", 1)
        with open(base_html, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[style] patched {base_html} to load {css_url}", file=sys.stderr)

    shutil.copy(CUSTOM_CSS_SRC, os.path.join(css_dir, CSS_FILENAME))
    print(f"[style] installed custom CSS into {css_dir}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
