#!/bin/sh
set -e

python3 /opt/render/render.py

exec /usr/local/searxng/entrypoint.sh "$@"
