#!/bin/sh
set -e

python3 /opt/render/render.py

exec /sbin/tini -- /usr/local/searxng/dockerfiles/docker-entrypoint.sh "$@"
