#!/usr/bin/env python3
"""
Regenerates /etc/searxng/settings.yml on every container start from:
  - settings.template.yml  (hand-edited header: general/search/server/outgoing/etc)
  - engines.json            (full registry of every engine SearXNG enables here,
                              each with its TOR_BYPASS_* env var name)
  - the container's actual environment (TOR_BYPASS_* values come from .env
    via docker-compose's env_file:)

For any engine whose TOR_BYPASS_<NAME> is true, an override goes into its
entry that disables Tor for that engine specifically (using_tor_proxy: false,
proxies: {}), so it connects directly instead of through the tor container.
Everything else inherits the global outgoing.proxies (routed through Tor)
by simply not setting proxies/using_tor_proxy at the engine level.
"""
import json
import os
import sys

TEMPLATE_PATH = "/opt/render/settings.template.yml"
REGISTRY_PATH = "/opt/render/engines.json"
OUTPUT_PATH = "/etc/searxng/settings.yml"

TRUE_VALUES = {"1", "true", "yes", "on"}


def is_truthy(value: str) -> bool:
    return value.strip().lower() in TRUE_VALUES


def yaml_name(name: str) -> str:
    """Quote the engine name only if it needs it for valid YAML."""
    needs_quote = any(c in name for c in [":", "#", '"', "'"]) or name != name.strip()
    if needs_quote:
        escaped = name.replace('"', '\\"')
        return f'"{escaped}"'
    return name


def render_engine(entry: dict) -> str:
    name = entry["name"]
    env_var = entry["env_var"]
    bypass = is_truthy(os.environ.get(env_var, "false"))

    lines = [f"  - name: {yaml_name(name)}", "    disabled: false"]

    if entry.get("use_mobile_ui"):
        lines.append("    use_mobile_ui: true")

    if bypass:
        lines.append("    using_tor_proxy: false")
        lines.append("    proxies: {}")

    return "\n".join(lines) + "\n"


def main() -> int:
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        header = f.read()

    with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
        registry = json.load(f)

    bypass_count = 0
    body_parts = []
    for entry in registry:
        rendered = render_engine(entry)
        if "using_tor_proxy: false" in rendered:
            bypass_count += 1
        body_parts.append(rendered)

    output = header + "engines:\n" + "\n".join(body_parts)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(output)

    print(
        f"[render] wrote {OUTPUT_PATH}: {len(registry)} engines, "
        f"{bypass_count} bypassing Tor",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
