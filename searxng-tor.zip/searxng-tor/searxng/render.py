#!/usr/bin/env python3
"""
Regenerates /etc/searxng/settings.yml on every container start from:
  - settings.template.yml  (hand-edited header: general/search/server/outgoing/etc)
  - the engine catalog of THIS image's own bundled defaults
    (/usr/local/searxng/searx/settings.yml) — discovered fresh at every
    start rather than kept in a static list, so it can never reference an
    engine that's been renamed or removed in the version actually
    running. (A static list did exactly that twice already.)
  - the container's actual environment (TOR_BYPASS_* values come from
    .env via docker-compose's env_file:)

Every discovered engine gets force-enabled (disabled: false) UNLESS the
base defaults mark it `inactive: true` — SearXNG's own convention for
"needs an API key you haven't provided," see docs/admin/settings/
settings_engines.html. A couple of engines (google, google images) are
inactive for an unrelated reason (fragile HTML scraping, not a missing
key) and are force-enabled anyway via ALWAYS_ENABLE below.

For any engine whose TOR_BYPASS_<NAME> is true, an override goes into
its entry that disables Tor for that engine specifically
(using_tor_proxy: false, proxies: {}), so it connects directly instead
of through the tor container. Everything else inherits the global
outgoing.proxies (routed through Tor) by simply not setting those keys.
"""
import os
import re
import sys

TEMPLATE_PATH = "/opt/render/settings.template.yml"
BASE_SETTINGS_PATH = "/usr/local/searxng/searx/settings.yml"
OUTPUT_PATH = "/etc/searxng/settings.yml"

TRUE_VALUES = {"1", "true", "yes", "on"}

# inactive: true here for reasons other than "needs an API key" — force
# these on anyway. Extend this if a future release adds another engine
# that's inactive for a similar non-credential reason.
ALWAYS_ENABLE = {"google", "google images"}

NAME_RE = re.compile(r"^  - name:\s*(.+?)\s*$")
INACTIVE_TRUE_RE = re.compile(r"^\s*inactive:\s*true\s*$")


def is_truthy(value: str) -> bool:
    return value.strip().lower() in TRUE_VALUES


def unquote(raw: str) -> str:
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        inner = raw[1:-1]
        if raw[0] == '"':
            inner = inner.replace('\\"', '"')
        return inner
    return raw


def discover_engines():
    """Returns [(name, inactive_by_default), ...] by scanning this image's
    own bundled settings.yml for `  - name: X` blocks under `engines:`,
    checking each block for a literal `inactive: true` line before the
    next block (or the section) ends."""
    with open(BASE_SETTINGS_PATH, "r", encoding="utf-8") as f:
        lines = f.readlines()

    engines = []
    in_engines_section = False
    current_name = None
    current_inactive = False

    def flush():
        if current_name is not None:
            engines.append((current_name, current_inactive))

    for line in lines:
        if not in_engines_section:
            if line.rstrip("\n") == "engines:":
                in_engines_section = True
            continue

        # a non-indented, non-blank line ends the engines: section
        if line.strip() and not line.startswith(" "):
            break

        m = NAME_RE.match(line)
        if m:
            flush()
            current_name = unquote(m.group(1))
            current_inactive = False
            continue

        if current_name is not None and INACTIVE_TRUE_RE.match(line):
            current_inactive = True

    flush()
    return engines


def normalize(name: str) -> str:
    out = []
    prev_us = False
    for ch in name.upper():
        if ch.isalnum():
            out.append(ch)
            prev_us = False
        else:
            if not prev_us:
                out.append("_")
                prev_us = True
    return "TOR_BYPASS_" + "".join(out).strip("_")


def yaml_name(name: str) -> str:
    """Quote the engine name only if it needs it for valid YAML."""
    needs_quote = any(c in name for c in [":", "#", '"', "'"]) or name != name.strip()
    if needs_quote:
        escaped = name.replace('"', '\\"')
        return f'"{escaped}"'
    return name


def render_engine(name: str) -> str:
    env_var = normalize(name)
    bypass = is_truthy(os.environ.get(env_var, "false"))

    lines = [f"  - name: {yaml_name(name)}", "    disabled: false"]

    if name == "google":
        lines.append("    use_mobile_ui: true")

    if bypass:
        lines.append("    using_tor_proxy: false")
        lines.append("    proxies: {}")

    return "\n".join(lines) + "\n"


def main() -> int:
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        header = f.read()

    all_engines = discover_engines()
    enabled = [
        name for name, inactive in all_engines
        if not inactive or name in ALWAYS_ENABLE
    ]
    skipped_count = len(all_engines) - len(enabled)

    body_parts = [render_engine(name) for name in enabled]
    bypass_count = sum(1 for p in body_parts if "using_tor_proxy: false" in p)

    output = header + "engines:\n" + "\n".join(body_parts)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(output)

    print(
        f"[render] wrote {OUTPUT_PATH}: {len(all_engines)} engines found in "
        f"this image, {len(enabled)} enabled ({bypass_count} bypassing Tor), "
        f"{skipped_count} left inactive (need an API key)",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
